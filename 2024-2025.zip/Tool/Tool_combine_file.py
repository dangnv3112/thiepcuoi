import os
from openpyxl import load_workbook, Workbook

# Thư mục chứa các file Excel cần gộp
folder_path = "D:/2024-2025/tool_combine_file/subheaden"

# Tạo Workbook mới để lưu kết quả gộp
combined_workbook = Workbook()
combined_sheet = combined_workbook.active
combined_sheet.title = "Combined"

# Duyệt qua tất cả các file Excel trong thư mục
for filename in os.listdir(folder_path):
    if filename.endswith(".xlsx"):
        # Đọc file Excel
        file_path = os.path.join(folder_path, filename)
        workbook = load_workbook(file_path)
        sheet = workbook.active  # Lấy sheet đầu tiên trong file

        # Sao chép dữ liệu từ file hiện tại vào file tổng hợp
        for row in sheet.iter_rows(values_only=True):
            combined_sheet.append(row)

# Lưu file Excel sau khi gộp
combined_workbook.save("D:/2024-2025/tool_combine_file/subheaden/file_tong_hop_subheaden.xlsx")

print("Đã gộp file Excel thành công!")
