import openpyxl
import shutil
import os

def copy_excel_to_multiple_files(source_file_path, sheet_name, output_names):
    # Kiểm tra file gốc có tồn tại hay không
    if not os.path.isfile(source_file_path):
        print(f"File '{source_file_path}' không tồn tại.")
        return
    
    print(f"Đang mở file: {source_file_path}")
    
    # Mở file Excel gốc
    wb = openpyxl.load_workbook(source_file_path)
    print(f"Đã mở file: {source_file_path}")
    
    # Kiểm tra sheet có tồn tại hay không
    if sheet_name not in wb.sheetnames:
        print(f"Sheet '{sheet_name}' không tồn tại trong file '{source_file_path}'.")
        return
    
    # Lặp qua danh sách các tên file đầu ra và tạo các file tương ứng
    for output_name in output_names:
        new_file_path = os.path.join(os.path.dirname(source_file_path), f'{output_name}.xlsx')
        shutil.copyfile(source_file_path, new_file_path)
        print(f"Đã tạo file: {new_file_path}")

# Đường dẫn tới file Excel gốc và tên sheet cần copy
source_file_path = 'C:/Users/vdang/OneDrive/Documents/WebView/tool_tach_file_theo_dkien.xlsx'  # Đường dẫn tuyệt đối
sheet_name = 'Sheet1'

# Danh sách các tên file bạn muốn tạo
output_names = ['File_1', 'File_2', 'File_3']  # Tùy chọn tên file

copy_excel_to_multiple_files(source_file_path, sheet_name, output_names)
